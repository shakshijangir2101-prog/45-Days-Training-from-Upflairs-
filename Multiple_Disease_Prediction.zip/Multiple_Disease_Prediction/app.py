# from flask import Flask,render_template,request

# app=Flask(__name__)

# import pickle
# import numpy as np


# app=Flask(__name__)

# model_heart=pickle.load(open("models/model_heart.pkl","rb"))
# model_Diabetes=pickle.load(open("models/model_Diabetes.pkl","rb"))
# model_Parkinson=pickle.load(open("models/model_Parkinson.pkl","wb"))

# @app.route("/")
# def home():
#     return render_template("index.html")
# @app.route("/Disease")

# # Heart Disease
# def heart():

#     return render_template("heart.html")

# @app.route("/predict")
# def predict_heart():

#     data=[
#         float(request.form["age"]),
#         float(request.form["sex"]),
#         float(request.form["chest pain type"]),
#         float(request.form["resting bps"]),
#         float(request.form["cholesterol"]),
#         float(request.form["fasting blood sugar"]),
#         float(request.form["resting ecg"]),
#         float(request.form["max heart rate"]),
#         float(request.form["exercise angina"]),
#         float(request.form["oldpeak"]),
#         float(request.form["ST slope"]),
#         float(request.form["target"])
#     ]

# #Diabetes
# def diabetes():

#     return render_template("diabetes.html")

# @app.route("/predict")
# def predict_diabetes():

#     data=[
#         float(request.form["Pregnancies"]),
#         float(request.form["Glucose"]),
#         float(request.form["BloodPressure"]),
#         float(request.form["SkinThickness"]),
#         float(request.form["Insulin"]),
#         float(request.form["BMI"]),
#         float(request.form["DiabetespedigreeFunction"]),
#         float(request.form["Age"]),
#         float(request.form["Outcome"]),
#     ]

# #Parkinson
# def heart():

#     return render_template("heart.html")

# @app.route("/predict")
# def predict_heart():

#     data=[
#         float(request.form["name"]),
#         float(request.form["MDVP:Fo(Hz)"]),
#         float(request.form["MDVP:Fhi(Hz)"]),
#         float(request.form["MDVP:Flo(Hz)"]),
#         float(request.form["MDVP:Jitter(%)"]),
#         float(request.form["MDVP:Jitter(Abs)"]),
#         float(request.form["MDVP:RAP"]),
#         float(request.form["MDVP:PPQ"]),
#         float(request.form["Jitter:DDP"]),
#         float(request.form["MDVP:Shimmer"]),
#         float(request.form["MDVP:Shimmer(dB)"]),
#         float(request.form["Shimmer:APQ3"]),
#         float(request.form["Shimmer:APQ5"]),
#         float(request.form["MDVP:APQ"]),
#         float(request.form["Shimmer:DDA"]),
#         float(request.form["NHR"]),
#         float(request.form["HNR"]),
#         float(request.form["status"]),
#         float(request.form["RPDE"]),
#         float(request.form["DFA"]),
#         float(request.form["spread1"]),
#         float(request.form["spread2"]),
#         float(request.form["D2"]),
#         float(request.form["PPE"])
#     ]

# if __name__=="__main__":
#     app.run(debug=True)

from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__)

# Load Models
heart_model = pickle.load(open("models/model_heart.pkl", "rb"))
diabetes_model = pickle.load(open("models/model_Diabetes.pkl", "rb"))
parkinson_model = pickle.load(open("models/model_Parkinson.pkl", "rb"))

# Load Scalers
heart_scaler = pickle.load(open("models/scaler_heart.pkl", "rb"))
diabetes_scaler = pickle.load(open("models/scaler_diabetes.pkl", "rb"))

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/heart")
def heart():
    return render_template("heart.html")

@app.route("/diabetes")
def diabetes():
    return render_template("diabetes.html")

@app.route("/parkinson")
def parkinson():
    return render_template("parkinson.html")

#Heart Disease Prediction
@app.route("/predict_heart", methods=["POST"])
def predict_heart():

    features = [

        float(request.form["age"]),
        float(request.form["sex"]),
        float(request.form["cp"]),
        float(request.form["trestbps"]),
        float(request.form["chol"]),
        float(request.form["fbs"]),
        float(request.form["restecg"]),
        float(request.form["thalach"]),
        float(request.form["exang"]),
        float(request.form["oldpeak"]),
        float(request.form["slope"])

    ]

    features = np.array(features).reshape(1, -1)

    features = heart_scaler.transform(features)

    prediction = heart_model.predict(features)

    if prediction[0] == 1:
        result = "Heart Disease Detected"
    else:
        result = "No Heart Disease"

    return render_template("result.html",
                           disease="Heart Disease",
                           prediction=result)


#Diabetes Disease Prediction
@app.route("/predict_diabetes", methods=["POST"])
def predict_diabetes():

    features = [

        float(request.form["Pregnancies"]),
        float(request.form["Glucose"]),
        float(request.form["BloodPressure"]),
        float(request.form["SkinThickness"]),
        float(request.form["Insulin"]),
        float(request.form["BMI"]),
        float(request.form["DiabetespedigreeFunction"]),
        float(request.form["Age"])

    ]

    features = np.array(features).reshape(1, -1)

    features = diabetes_scaler.transform(features)

    prediction = diabetes_model.predict(features)

    if prediction[0] == 1:
        result = "Diabetes Detected"
    else:
        result = "No Diabetes"

    return render_template(
        "result.html",
        disease="Diabetes",
        prediction=result
    )


#Parkinson Disease Prediction
@app.route("/predict_parkinson", methods=["POST"])
def predict_parkinson():

    features = [

        float(request.form["Fo"]),
        float(request.form["Fhi"]),
        float(request.form["Flo"]),
        float(request.form["JitterPercent"]),
        float(request.form["JitterAbs"]),
        float(request.form["RAP"]),
        float(request.form["PPQ"]),
        float(request.form["DDP"]),
        float(request.form["Shimmer"]),
        float(request.form["ShimmerDB"]),
        float(request.form["APQ3"]),
        float(request.form["APQ5"]),
        float(request.form["APQ"]),
        float(request.form["DDA"]),
        float(request.form["NHR"]),
        float(request.form["HNR"]),
        float(request.form["RPDE"]),
        float(request.form["DFA"]),
        float(request.form["spread1"]),
        float(request.form["spread2"]),
        float(request.form["D2"]),
        float(request.form["PPE"])

    ]

    features = np.array(features).reshape(1, -1)

    prediction = parkinson_model.predict(features)

    if prediction[0] == 1:
        result = "Parkinson Disease Detected"
    else:
        result = "No Parkinson Disease"

    return render_template(
        "result.html",
        disease="Parkinson Disease",
        prediction=result
    )

if __name__=="__main__":
    app.run(debug=True)