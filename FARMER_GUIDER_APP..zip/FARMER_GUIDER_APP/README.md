# Crop Recommendation System

## Project Description
This is a Machine Learning based Crop Recommendation System developed using Python and Flask. The system recommends the most suitable crop based on soil and weather conditions.

## Features
- Crop prediction using Machine Learning
- User-friendly web interface
- Flask-based web application
- Uses trained Random Forest model

## Technologies Used
- Python
- Flask
- Pandas
- NumPy
- Scikit-learn
- HTML
- CSS

## Input Parameters
- Nitrogen (N)
- Phosphorus (P)
- Potassium (K)
- Temperature
- Humidity
- pH
- Rainfall

## Output
- Recommended Crop

## Project Structure


```
FARMER_GUIDER_APP/
│
├── app.py
├── models/
│   ├── crop_recommendation_model.pkl
│   ├── crop_recom_scaler.pkl
│   └── crop_recom_encoder.pkl
├── templates/
│   ├── index.html
│   ├── crop.html
│   └── result.html
├── static/
└── README.md


````md
## How to Run
1. Install the required libraries.
2. Run the application:
   python app.py
3. Open the browser and visit:
   http://127.0.0.1:5000/

## Author
Mamta Rathore