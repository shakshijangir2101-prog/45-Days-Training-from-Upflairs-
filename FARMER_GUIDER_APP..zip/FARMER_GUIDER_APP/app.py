from flask import Flask,render_template,request
app = Flask(__name__)
import pickle
import numpy as np

app= Flask(__name__)

model = pickle.load(open("models/crop_recommendation_model.pkl","rb"))
scaler = pickle.load(open("models/crop_recom_scaler.pkl","rb"))
encoder = pickle.load(open("models/crop_recom_encoder.pkl","rb"))

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/crop")
def crop():
    return render_template("crop.html")

@app.route("/predict_crop", methods=["POST"])
def predict_crop():

    N=float(request.form["N"])
    P=float(request.form["P"])
    K=float(request.form["K"])
    temperature=float(request.form["temperature"])
    humidity=float(request.form["humidity"])
    ph=float(request.form["ph"])
    rainfall=float(request.form["rainfall"])

    data=np.array([[N,P,K,temperature,humidity,ph,rainfall]])

    data=scaler.transform(data)

    prediction=model.predict(data)

    crop=encoder.inverse_transform(prediction)

    return render_template("result.html",
                           prediction=crop[0])

if __name__=="__main__":
    app.run(debug=True)